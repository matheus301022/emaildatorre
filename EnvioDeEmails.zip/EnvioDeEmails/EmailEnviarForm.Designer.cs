namespace EnvioDeEmails
{
    partial class EmailEnviarForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.destinatarioLabel = new System.Windows.Forms.Label();
            this.destinatarioTextBox = new System.Windows.Forms.TextBox();
            this.assuntoLabel = new System.Windows.Forms.Label();
            this.assuntoTextBox = new System.Windows.Forms.TextBox();
            this.mensagemLabel = new System.Windows.Forms.Label();
            this.mensagemTextBox = new System.Windows.Forms.TextBox();
            this.enviarButton = new System.Windows.Forms.Button();
            this.fecharButton = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            //
            // destinatarioLabel
            //
            this.destinatarioLabel.AutoSize = true;
            this.destinatarioLabel.Location = new System.Drawing.Point(12, 9);
            this.destinatarioLabel.Name = "destinatarioLabel";
            this.destinatarioLabel.Size = new System.Drawing.Size(92, 15);
            this.destinatarioLabel.TabIndex = 0;
            this.destinatarioLabel.Text = "Email de Destino";
            //
            // destinatarioTextBox
            //
            this.destinatarioTextBox.Location = new System.Drawing.Point(12, 27);
            this.destinatarioTextBox.Name = "destinatarioTextBox";
            this.destinatarioTextBox.Size = new System.Drawing.Size(260, 23);
            this.destinatarioTextBox.TabIndex = 1;
            //
            // assuntoLabel
            //
            this.assuntoLabel.AutoSize = true;
            this.assuntoLabel.Location = new System.Drawing.Point(12, 58);
            this.assuntoLabel.Name = "assuntoLabel";
            this.assuntoLabel.Size = new System.Drawing.Size(48, 15);
            this.assuntoLabel.TabIndex = 2;
            this.assuntoLabel.Text = "Assunto";
            //
            // assuntoTextBox
            //
            this.assuntoTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.assuntoTextBox.Location = new System.Drawing.Point(12, 76);
            this.assuntoTextBox.Name = "assuntoTextBox";
            this.assuntoTextBox.Size = new System.Drawing.Size(756, 23);
            this.assuntoTextBox.TabIndex = 3;
            //
            // mensagemLabel
            //
            this.mensagemLabel.AutoSize = true;
            this.mensagemLabel.Location = new System.Drawing.Point(12, 107);
            this.mensagemLabel.Name = "mensagemLabel";
            this.mensagemLabel.Size = new System.Drawing.Size(61, 15);
            this.mensagemLabel.TabIndex = 4;
            this.mensagemLabel.Text = "Mensagem";
            //
            // mensagemTextBox
            //
            this.mensagemTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mensagemTextBox.Location = new System.Drawing.Point(12, 125);
            this.mensagemTextBox.Multiline = true;
            this.mensagemTextBox.Name = "mensagemTextBox";
            this.mensagemTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.mensagemTextBox.Size = new System.Drawing.Size(756, 290);
            this.mensagemTextBox.TabIndex = 5;
            //
            // enviarButton
            //
            this.enviarButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.enviarButton.Location = new System.Drawing.Point(612, 424);
            this.enviarButton.Name = "enviarButton";
            this.enviarButton.Size = new System.Drawing.Size(75, 28);
            this.enviarButton.TabIndex = 6;
            this.enviarButton.Text = "Enviar";
            this.enviarButton.UseVisualStyleBackColor = true;
            this.enviarButton.Click += new System.EventHandler(this.enviarButton_Click);
            //
            // fecharButton
            //
            this.fecharButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.fecharButton.Location = new System.Drawing.Point(693, 424);
            this.fecharButton.Name = "fecharButton";
            this.fecharButton.Size = new System.Drawing.Size(75, 28);
            this.fecharButton.TabIndex = 7;
            this.fecharButton.Text = "Fechar";
            this.fecharButton.UseVisualStyleBackColor = true;
            this.fecharButton.Click += new System.EventHandler(this.fecharButton_Click);
            //
            // errorProvider1
            //
            this.errorProvider1.ContainerControl = this;
            //
            // EmailEnviarForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 464);
            this.Controls.Add(this.fecharButton);
            this.Controls.Add(this.enviarButton);
            this.Controls.Add(this.mensagemTextBox);
            this.Controls.Add(this.mensagemLabel);
            this.Controls.Add(this.assuntoTextBox);
            this.Controls.Add(this.assuntoLabel);
            this.Controls.Add(this.destinatarioTextBox);
            this.Controls.Add(this.destinatarioLabel);
            this.Name = "EmailEnviarForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Envio de Emails";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button fecharButton;
        private System.Windows.Forms.TextBox mensagemTextBox;
        private System.Windows.Forms.Label mensagemLabel;
        private System.Windows.Forms.TextBox assuntoTextBox;
        private System.Windows.Forms.Label assuntoLabel;
        private System.Windows.Forms.TextBox destinatarioTextBox;
        private System.Windows.Forms.Label destinatarioLabel;
        private System.Windows.Forms.Button enviarButton;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}
