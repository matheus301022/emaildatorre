using System;
using System.Net.Mail;
using System.Windows.Forms;

namespace EnvioDeEmails
{
    public partial class EmailEnviarForm : Form
    {
        public EmailEnviarForm()
        {
            InitializeComponent();
        }

        private bool EmailValido(string endereco)
        {
            try
            {
                MailAddress m = new MailAddress(endereco);
                return m.Address == endereco.Trim();
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private bool ValidarCampos()
        {
            bool ok = true;
            errorProvider1.Clear();

            if (!EmailValido(destinatarioTextBox.Text))
            {
                errorProvider1.SetError(destinatarioTextBox, "Informe um e-mail de destino valido.");
                ok = false;
            }
            if (string.IsNullOrWhiteSpace(assuntoTextBox.Text))
            {
                errorProvider1.SetError(assuntoTextBox, "Informe o assunto.");
                ok = false;
            }
            if (string.IsNullOrWhiteSpace(mensagemTextBox.Text))
            {
                errorProvider1.SetError(mensagemTextBox, "Digite a mensagem.");
                ok = false;
            }
            return ok;
        }

        private void enviarButton_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;

            try
            {
                Cursor = Cursors.WaitCursor;
                enviarButton.Enabled = false;

                EmailHelper.Enviar(
                    destinatarioTextBox.Text.Trim(),
                    assuntoTextBox.Text.Trim(),
                    mensagemTextBox.Text);

                MessageBox.Show("E-mail enviado com sucesso!", "Envio de Emails",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                destinatarioTextBox.Clear();
                assuntoTextBox.Clear();
                mensagemTextBox.Clear();
                destinatarioTextBox.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nao foi possivel enviar o e-mail:\n" + ex.Message,
                    "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                enviarButton.Enabled = true;
                Cursor = Cursors.Default;
            }
        }

        private void fecharButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
