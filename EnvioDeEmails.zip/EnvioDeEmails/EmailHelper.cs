using System;
using System.Configuration;
using System.Net;
using System.Net.Mail;

namespace EnvioDeEmails
{
    /// <summary>
    /// Metodo pronto para envio de e-mail. As configuracoes (servidor, porta,
    /// usuario, senha...) ficam nas chaves <appSettings> do App.config.
    /// </summary>
    public static class EmailHelper
    {
        public static void Enviar(string destinatario, string assunto, string mensagem)
        {
            string host      = ConfigurationManager.AppSettings["EmailHost"];
            int    porta     = int.Parse(ConfigurationManager.AppSettings["EmailPort"]);
            bool   ssl       = bool.Parse(ConfigurationManager.AppSettings["EmailEnableSsl"]);
            string usuario   = ConfigurationManager.AppSettings["EmailUser"];
            string senha     = ConfigurationManager.AppSettings["EmailPassword"];
            string remetente = ConfigurationManager.AppSettings["EmailFrom"];
            string nomeRem   = ConfigurationManager.AppSettings["EmailFromName"];

            using (MailMessage email = new MailMessage())
            {
                email.From = new MailAddress(remetente, nomeRem);
                email.To.Add(new MailAddress(destinatario));
                email.Subject = assunto;
                email.Body = mensagem;
                email.IsBodyHtml = false;

                using (SmtpClient smtp = new SmtpClient(host, porta))
                {
                    smtp.EnableSsl = ssl;
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential(usuario, senha);
                    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtp.Send(email);
                }
            }
        }
    }
}
