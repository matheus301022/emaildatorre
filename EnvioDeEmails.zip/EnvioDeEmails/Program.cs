using System;
using System.Windows.Forms;

namespace EnvioDeEmails
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new EmailEnviarForm());
        }
    }
}
